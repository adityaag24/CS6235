class input2 {
    public static void main(String[] args){
        A a;
        A b;
        A r1;
        boolean checker;
        a = new A();//R1
        b = new A();//R2
        checker = false;
        /*a alias? b*/ 
        if(checker){
            r1 = a;//R1
        }else{
            r1 = b;//R2
        }
        /*r1 alias? a*/
        /*r1 alias? b*/
        System.out.println(checker);
    }
}
class A{
    int f0;
    public int f0(){
        f0 = 0;
        System.out.println(f0);
        return f0;
    }
}
